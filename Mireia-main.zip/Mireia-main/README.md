#Mireia
Hacer ansible y pagina web (http://hjm.rf.gd) 
- Crear usuarios (Hecho)
- sshpass
- ansible
- samba (Hecho)
- squid (Configuracion en squid.txt)
- crontab
- docker compose
- docker network
- rsync
- DNS (Configuracion en dns(bind9).txt)   (Hecho) 
- Apache 
- NextCloud
- Kea (Configuracion en kea.txt)  (Hecho)
- Netplan (Configuracion en netplan.txt)  (Hecho)  
